import { useEffect, useState } from "react";

const findings = [
  { color: "#ef4444", text: "Unusual ATM withdrawals detected at irregular hours — 12 AM to 4 AM activity window flagged" },
  { color: "#ef4444", text: "Repeated transactions to same merchant (GAS FILLING STATION, ₹500 appears 58×)" },
  { color: "var(--amber)", text: "Activity outside usual transaction time window on 23 occasions" },
  { color: "var(--amber)", text: "Structuring pattern detected: ₹9,800–₹10,200 range (23 transactions, total ₹2,27,800)" },
  { color: "var(--teal)", text: "Cash flow forecast: High overdraft risk expected on Jun 26 based on current trajectory" },
];

const columnFields = ["id", "debit_credit", "amount", "balance", "date", "time", "transaction_type", "merchant"];

function SectionLabel({ children }) {
  return (
    <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "var(--teal)", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
      <span style={{ display: "block", width: 28, height: 1, background: "var(--teal)" }} />
      {children}
    </div>
  );
}

export default function UploadPage() {
  const [dragging, setDragging] = useState(false);
  const [uploaded, setUploaded] = useState(false);

  useEffect(() => { window.scrollTo(0, 0); }, []);

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    setUploaded(true);
    setTimeout(() => setUploaded(false), 3000);
  };

  return (
    <section style={{ minHeight: "100vh", padding: "120px 48px 80px", background: "var(--bg2)", borderTop: "1px solid var(--border)" }}>
      <SectionLabel>Analyze Now</SectionLabel>
      <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "clamp(2rem, 4vw, 3.2rem)", letterSpacing: "-0.03em", marginBottom: 16, lineHeight: 1.1 }}>
        Upload & Get Results
      </h2>
      <p style={{ color: "var(--muted)", maxWidth: 540, lineHeight: 1.7, marginBottom: 64, fontWeight: 300 }}>
        Drop a statement and receive a complete forensic analysis — risk score, flagged transactions, and an evidence-ready PDF — within seconds.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48, alignItems: "start" }}>
        {/* Left: Upload */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {/* Drop zone */}
          <div
            onDragEnter={e => { e.preventDefault(); setDragging(true); }}
            onDragOver={e => { e.preventDefault(); setDragging(true); }}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
            style={{
              border: `2px dashed ${dragging ? "var(--teal)" : "rgba(0,212,170,0.25)"}`,
              borderRadius: 20,
              padding: "52px 36px",
              display: "flex", flexDirection: "column",
              alignItems: "center", justifyContent: "center", textAlign: "center",
              gap: 16,
              background: dragging ? "rgba(0,212,170,0.06)" : uploaded ? "rgba(0,212,170,0.04)" : "rgba(0,212,170,0.02)",
              transition: "all 0.3s",
              cursor: "pointer",
              boxShadow: dragging ? "0 0 32px rgba(0,212,170,0.12)" : "none",
            }}
          >
            <div style={{ fontSize: "3rem" }}>{uploaded ? "✅" : "📂"}</div>
            <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.15rem" }}>
              {uploaded ? "File Received!" : "Drop Your Bank Statement"}
            </div>
            <div style={{ fontSize: "0.82rem", color: "var(--muted)", lineHeight: 1.6 }}>
              {uploaded
                ? "Analysis running... results will appear shortly."
                : "Drag and drop your file here, or click to browse.\nColumns are auto-detected and standardized."}
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center" }}>
              {["CSV", "PDF", "PNG / JPG"].map(f => (
                <span key={f} style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 6, padding: "4px 12px", fontFamily: "var(--font-mono)", fontSize: "0.7rem", color: "var(--muted)" }}>{f}</span>
              ))}
            </div>
            <button
              onClick={() => { setUploaded(true); setTimeout(() => setUploaded(false), 3000); }}
              style={{
                marginTop: 4,
                background: "var(--teal)", color: "#040d1a",
                padding: "12px 28px", borderRadius: 8,
                border: "none", cursor: "pointer",
                fontFamily: "var(--font-body)", fontWeight: 600, fontSize: "0.92rem",
                transition: "all 0.2s",
              }}
              onMouseEnter={e => { e.currentTarget.style.background = "var(--teal2)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "var(--teal)"; e.currentTarget.style.transform = ""; }}
            >Browse Files</button>
          </div>

          {/* Column reference */}
          <div style={{ padding: "20px 22px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 14 }}>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.68rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 14 }}>
              Expected CSV Columns
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {columnFields.map(f => (
                <span key={f} style={{
                  background: "rgba(0,212,170,0.06)", border: "1px solid rgba(0,212,170,0.2)",
                  borderRadius: 6, padding: "4px 12px",
                  fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "var(--teal)",
                }}>{f}</span>
              ))}
            </div>
            <p style={{ marginTop: 14, fontSize: "0.78rem", color: "var(--muted)", lineHeight: 1.6 }}>
              Any variation in column naming is handled automatically. Max file size:{" "}
              <span style={{ color: "var(--text)" }}>200 MB</span>.
            </p>
          </div>
        </div>

        {/* Right: Sample output */}
        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.7rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
            // Sample Analysis Output
          </div>

          {/* Risk score card */}
          <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 24 }}>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.7rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 18 }}>
              Overall Risk Score
            </div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginBottom: 14 }}>
              <span style={{ fontFamily: "var(--font-display)", fontSize: "3.5rem", fontWeight: 800, lineHeight: 1, color: "var(--amber)" }}>62.8</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: "1.2rem", color: "var(--muted)" }}>/ 100</span>
            </div>

            <span style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.25)",
              color: "#ef4444", padding: "4px 14px", borderRadius: 6,
              fontFamily: "var(--font-mono)", fontSize: "0.7rem", fontWeight: 600,
              textTransform: "uppercase", letterSpacing: "0.05em",
            }}>⚠ High Risk</span>

            <div style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "12px 16px", marginTop: 16,
              background: "rgba(239,68,68,0.05)", border: "1px solid rgba(239,68,68,0.15)", borderRadius: 8,
              fontSize: "0.82rem",
            }}>
              <span style={{ color: "var(--muted)" }}>Flagged Transactions</span>
              <span style={{ fontFamily: "var(--font-mono)", color: "#ef4444", fontWeight: 600 }}>868 / 985</span>
            </div>
          </div>

          {/* Key findings card */}
          <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 24 }}>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.7rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 18 }}>
              Key Findings
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {findings.map((f, i) => (
                <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 12, fontSize: "0.82rem", color: "var(--muted)", lineHeight: 1.55 }}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: f.color, marginTop: 6, flexShrink: 0 }} />
                  {f.text}
                </div>
              ))}
            </div>
          </div>

          {/* Generate PDF button */}
          <button
            style={{
              width: "100%",
              background: "linear-gradient(135deg, rgba(0,212,170,0.1), rgba(59,130,246,0.1))",
              border: "1px solid rgba(0,212,170,0.3)",
              color: "var(--teal)",
              padding: 18, borderRadius: 12,
              fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.95rem",
              cursor: "pointer", transition: "all 0.3s",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
              letterSpacing: "-0.01em",
            }}
            onMouseEnter={e => { e.currentTarget.style.boxShadow = "0 0 24px rgba(0,212,170,0.2)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
            onMouseLeave={e => { e.currentTarget.style.boxShadow = "none"; e.currentTarget.style.transform = ""; }}
            onClick={() => alert("PDF generation — connect to backend API")}
          >
            📄 Generate Forensic Evidence PDF
          </button>
        </div>
      </div>
    </section>
  );
}
