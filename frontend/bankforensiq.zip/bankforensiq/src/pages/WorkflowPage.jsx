import { useEffect } from "react";

const steps = [
  { icon: "📤", num: 1, title: "Upload", desc: "CSV, PDF, or scanned image — any format accepted" },
  { icon: "🔍", num: 2, title: "Extract", desc: "OCR & parsing engine pulls all transaction fields" },
  { icon: "🧹", num: 3, title: "Clean", desc: "Deduplication, missing value handling, standardization" },
  { icon: "📊", num: 4, title: "Analyze", desc: "Trends, spending patterns, merchant & anomaly detection" },
  { icon: "🛡️", num: 5, title: "Risk Score", desc: "Rule-based + AI models assign 0–100 risk per account" },
  { icon: "📈", num: 6, title: "Visualize", desc: "Interactive dashboards, timelines, drill-down charts" },
  { icon: "📄", num: 7, title: "Report", desc: "Court-ready forensic PDF with findings & recommendations" },
];

const schemaFields = [
  { name: "id", type: "uuid", desc: "Unique transaction identifier" },
  { name: "debit_credit", type: "enum", desc: "DEBIT or CREDIT" },
  { name: "amount", type: "float", desc: "Transaction value in ₹" },
  { name: "balance", type: "float", desc: "Running account balance" },
  { name: "date", type: "date", desc: "Transaction date (YYYY-MM-DD)" },
  { name: "time", type: "time", desc: "HH:MM:SS timestamp" },
  { name: "transaction_type", type: "string", desc: "UPI / NEFT / CARD / ATM" },
  { name: "merchant", type: "string", desc: "Payee or merchant name" },
];

const sampleRows = [
  { type: "DEBIT", amount: "₹500", date: "2023-07-26", merchant: "GAS STATION", dc: "debit" },
  { type: "CREDIT", amount: "₹15,000", date: "2024-01-02", merchant: "NEFT/Salary", dc: "credit" },
  { type: "DEBIT", amount: "₹3,000", date: "2023-08-22", merchant: "UPI/3234", dc: "debit" },
  { type: "DEBIT", amount: "₹1,000", date: "2023-08-07", merchant: "ATM", dc: "debit" },
  { type: "CREDIT", amount: "₹45,000", date: "2023-11-01", merchant: "NEFT/Transfer", dc: "credit" },
];

function SectionLabel({ children }) {
  return (
    <div style={{
      fontFamily: "var(--font-mono)", fontSize: "0.72rem",
      color: "var(--teal)", textTransform: "uppercase", letterSpacing: "0.12em",
      marginBottom: 16, display: "flex", alignItems: "center", gap: 10,
    }}>
      <span style={{ display: "block", width: 28, height: 1, background: "var(--teal)" }} />
      {children}
    </div>
  );
}

export default function WorkflowPage() {
  useEffect(() => { window.scrollTo(0, 0); }, []);

  return (
    <section style={{ minHeight: "100vh", padding: "120px 48px 80px", background: "var(--bg2)", borderTop: "1px solid var(--border)" }}>
      <SectionLabel>System Pipeline</SectionLabel>
      <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "clamp(2rem, 4vw, 3.2rem)", letterSpacing: "-0.03em", marginBottom: 16, lineHeight: 1.1 }}>
        How It Works
      </h2>
      <p style={{ color: "var(--muted)", maxWidth: 520, lineHeight: 1.7, marginBottom: 64, fontWeight: 300 }}>
        Seven automated stages transform raw bank statements into structured, risk-scored forensic data — zero manual effort required.
      </p>

      {/* Workflow Steps */}
      <div style={{ position: "relative" }}>
        {/* Connector line */}
        <div style={{
          position: "absolute", top: 28, left: 28, right: 28, height: 1,
          background: "linear-gradient(to right, var(--teal), transparent)",
          opacity: 0.25, pointerEvents: "none",
        }} />
        <div style={{ display: "flex", gap: 0 }}>
          {steps.map((s) => (
            <StepCard key={s.num} {...s} />
          ))}
        </div>
      </div>

      {/* Schema + Preview */}
      <div style={{ marginTop: 80, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, alignItems: "start" }}>
        {/* Schema table */}
        <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, overflow: "hidden" }}>
          <div style={{
            padding: "16px 24px", borderBottom: "1px solid var(--border)",
            display: "flex", alignItems: "center", gap: 10,
            fontFamily: "var(--font-mono)", fontSize: "0.78rem", color: "var(--teal)",
          }}>
            <span style={{ width: 8, height: 8, background: "var(--teal)", borderRadius: "50%" }} />
            transaction_schema.json — Standard Fields
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                {["Field", "Type", "Description"].map(h => (
                  <th key={h} style={{ padding: "10px 24px", textAlign: "left", fontFamily: "var(--font-mono)", fontSize: "0.66rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.06em", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {schemaFields.map((f, i) => (
                <tr key={f.name} style={{ borderBottom: i < schemaFields.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none" }}>
                  <td style={{ padding: "12px 24px", fontFamily: "var(--font-mono)", fontSize: "0.8rem", color: "var(--teal)" }}>{f.name}</td>
                  <td style={{ padding: "12px 24px", fontFamily: "var(--font-mono)", fontSize: "0.8rem", color: "var(--blue)" }}>{f.type}</td>
                  <td style={{ padding: "12px 24px", fontSize: "0.75rem", color: "var(--muted)" }}>{f.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Right: preview + note */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <SectionLabel>Sample Data Preview</SectionLabel>
          <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 16, padding: 20 }}>
            {/* Header row */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 6, padding: "8px 10px" }}>
              {["type", "amount", "date", "merchant"].map(h => (
                <span key={h} style={{ fontFamily: "var(--font-mono)", fontSize: "0.64rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</span>
              ))}
            </div>
            {sampleRows.map((r, i) => (
              <PreviewRow key={i} row={r} />
            ))}
          </div>

          <div style={{ padding: "18px 22px", background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12 }}>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.68rem", color: "var(--muted)", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.06em" }}>
              Auto-Detection
            </div>
            <p style={{ fontSize: "0.82rem", color: "var(--text)", lineHeight: 1.7, fontWeight: 300 }}>
              Columns are matched automatically regardless of header naming convention. The system handles{" "}
              <span style={{ color: "var(--teal)" }}>valueDate</span>,{" "}
              <span style={{ color: "var(--teal)" }}>transactionDate</span>,{" "}
              <span style={{ color: "var(--teal)" }}>Debit/Credit</span>, or any bank-specific format.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function StepCard({ icon, num, title, desc }) {
  return (
    <div
      style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 14, padding: "0 12px", textAlign: "center", position: "relative", zIndex: 1 }}
      onMouseEnter={e => {
        const icon = e.currentTarget.querySelector(".wf-icon");
        if (icon) { icon.style.background = "rgba(0,212,170,0.1)"; icon.style.borderColor = "var(--teal)"; icon.style.boxShadow = "0 0 20px rgba(0,212,170,0.2)"; icon.style.transform = "translateY(-4px)"; }
      }}
      onMouseLeave={e => {
        const icon = e.currentTarget.querySelector(".wf-icon");
        if (icon) { icon.style.background = "var(--surface)"; icon.style.borderColor = "var(--border)"; icon.style.boxShadow = "none"; icon.style.transform = ""; }
      }}
    >
      <div className="wf-icon" style={{
        width: 56, height: 56, background: "var(--surface)", border: "1px solid var(--border)",
        borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "1.25rem", position: "relative", transition: "all 0.3s",
      }}>
        {icon}
        <span style={{
          position: "absolute", top: -8, right: -8, width: 20, height: 20,
          background: "var(--teal)", color: "#040d1a", borderRadius: "50%",
          fontFamily: "var(--font-mono)", fontSize: "0.62rem", fontWeight: 700,
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>{num}</span>
      </div>
      <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.88rem" }}>{title}</div>
      <div style={{ fontSize: "0.75rem", color: "var(--muted)", lineHeight: 1.5 }}>{desc}</div>
    </div>
  );
}

function PreviewRow({ row }) {
  const [hovered, setHovered] = useState(false);
  // inline import useState
  const [h, setH] = _useState(false);

  return (
    <div
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8,
        padding: "9px 10px", marginBottom: 4,
        background: h ? "rgba(0,212,170,0.05)" : "rgba(255,255,255,0.02)",
        border: h ? "1px solid var(--border)" : "1px solid transparent",
        borderRadius: 6, transition: "all 0.2s", cursor: "default",
      }}
    >
      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: row.dc === "debit" ? "#ef4444" : "var(--teal)" }}>{row.type}</span>
      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem" }}>{row.amount}</span>
      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "var(--muted)" }}>{row.date}</span>
      <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "var(--muted)" }}>{row.merchant}</span>
    </div>
  );
}

// Fix: need useState in PreviewRow
import { useState as _useState } from "react";
