import { useEffect, useRef } from "react";

const txns = [
  { merchant: "GAS FILLING STATION", meta: "2023-07-26 · CARD", amount: "−₹500.00", type: "debit" },
  { merchant: "UPI/3234", meta: "2023-08-22 · UPI", amount: "−₹3,000.00", type: "debit" },
  { merchant: "NEFT / Salary", meta: "2024-01-02 · NEFT", amount: "+₹15,000.00", type: "credit" },
  { merchant: "ATM / 5188810", meta: "2023-08-07 · ATM", amount: "−₹1,000.00", type: "debit" },
];

const stats = [
  { val: "0–100", label: "Risk Score" },
  { val: "8", label: "AI Models" },
  { val: "3", label: "File Formats" },
  { val: "7", label: "Pipeline Steps" },
];

export default function HeroPage({ setPage }) {
  const cardRef = useRef(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <section style={{
      minHeight: "100vh",
      display: "flex", flexDirection: "column",
      justifyContent: "center",
      padding: "140px 48px 80px",
      position: "relative", overflow: "hidden",
    }}>
      {/* Grid background */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        backgroundImage: "linear-gradient(rgba(0,212,170,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,170,0.04) 1px, transparent 1px)",
        backgroundSize: "48px 48px",
        WebkitMaskImage: "radial-gradient(ellipse 80% 60% at 50% 40%, black, transparent)",
      }} />

      {/* Orbs */}
      <div style={{ position: "absolute", width: 580, height: 580, borderRadius: "50%", background: "rgba(0,212,170,0.07)", filter: "blur(80px)", top: -100, right: -100, pointerEvents: "none" }} />
      <div style={{ position: "absolute", width: 380, height: 380, borderRadius: "50%", background: "rgba(59,130,246,0.06)", filter: "blur(80px)", bottom: 0, left: "30%", pointerEvents: "none" }} />

      {/* Badge */}
      <div style={{
        display: "inline-flex", alignItems: "center", gap: 8,
        background: "rgba(0,212,170,0.1)", border: "1px solid rgba(0,212,170,0.25)",
        borderRadius: 100, padding: "6px 14px", width: "fit-content",
        fontFamily: "var(--font-mono)", fontSize: "0.7rem",
        color: "var(--teal)", letterSpacing: "0.08em", textTransform: "uppercase",
        marginBottom: 28,
        animation: "fadeUp 0.6s ease both",
      }}>
        <span style={{ width: 7, height: 7, background: "var(--teal)", borderRadius: "50%", animation: "pulse 2s infinite" }} />
        AI-Powered Financial Forensics
      </div>

      {/* H1 */}
      <h1 style={{
        fontFamily: "var(--font-display)", fontWeight: 800,
        fontSize: "clamp(2.8rem, 6vw, 5.5rem)", lineHeight: 1.0,
        letterSpacing: "-0.04em", maxWidth: 820, marginBottom: 24,
        animation: "fadeUp 0.6s 0.1s ease both", animationFillMode: "both",
      }}>
        Detect{" "}
        <span style={{ color: "var(--teal)" }}>Fraud</span>
        <br />
        Before It{" "}
        <span style={{ WebkitTextStroke: "2px rgba(0,212,170,0.4)", color: "transparent" }}>Hides.</span>
      </h1>

      {/* Sub */}
      <p style={{
        fontSize: "1.08rem", color: "var(--muted)", lineHeight: 1.7,
        maxWidth: 540, marginBottom: 40, fontWeight: 300,
        animation: "fadeUp 0.6s 0.2s ease both", animationFillMode: "both",
      }}>
        Automated bank statement analysis that extracts, standardizes, scores risk,
        and generates court-ready forensic reports — in minutes, not months.
      </p>

      {/* CTA Buttons */}
      <div style={{
        display: "flex", gap: 16, alignItems: "center",
        animation: "fadeUp 0.6s 0.3s ease both", animationFillMode: "both",
      }}>
        <button
          onClick={() => setPage("upload")}
          style={{
            background: "var(--teal)", color: "#040d1a",
            padding: "14px 32px", borderRadius: 8,
            border: "none", cursor: "pointer",
            fontFamily: "var(--font-body)", fontWeight: 600, fontSize: "0.95rem",
            display: "flex", alignItems: "center", gap: 8,
            transition: "all 0.2s",
          }}
          onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,212,170,0.3)"; }}
          onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
        >↑ Upload Statement</button>

        <button
          onClick={() => setPage("workflow")}
          style={{
            background: "transparent", color: "var(--text)",
            padding: "14px 32px", borderRadius: 8,
            border: "1px solid var(--border)", cursor: "pointer",
            fontFamily: "var(--font-body)", fontWeight: 500, fontSize: "0.95rem",
            transition: "all 0.2s",
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--teal)"; e.currentTarget.style.color = "var(--teal)"; e.currentTarget.style.background = "rgba(0,212,170,0.05)"; }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.color = "var(--text)"; e.currentTarget.style.background = "transparent"; }}
        >View Workflow →</button>
      </div>

      {/* Stats */}
      <div style={{
        display: "flex", gap: 48,
        marginTop: 72, paddingTop: 40,
        borderTop: "1px solid var(--border)",
        animation: "fadeUp 0.6s 0.4s ease both", animationFillMode: "both",
      }}>
        {stats.map(({ val, label }) => (
          <div key={label} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "2rem", fontWeight: 800, color: "var(--teal)", letterSpacing: "-0.03em" }}>{val}</span>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Floating card */}
      <div ref={cardRef} style={{
        position: "absolute", right: "5%", top: "50%", transform: "translateY(-50%)",
        width: 375,
        background: "rgba(10,31,61,0.92)",
        border: "1px solid var(--border)",
        borderRadius: 16, padding: 24,
        backdropFilter: "blur(20px)",
        boxShadow: "0 24px 64px rgba(0,0,0,0.4), var(--glow)",
        animation: "float 6s ease-in-out infinite, fadeIn 0.8s 0.5s ease both",
        animationFillMode: "both",
      }}>
        {/* Card header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.7rem", color: "var(--muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
            // Live Transaction Feed
          </span>
          <span style={{
            background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)",
            color: "#ef4444", padding: "3px 10px", borderRadius: 100,
            fontSize: "0.68rem", fontFamily: "var(--font-mono)", fontWeight: 500,
          }}>HIGH RISK</span>
        </div>

        {/* Transactions */}
        {txns.map((t, i) => (
          <div key={i} style={{
            display: "flex", justifyContent: "space-between", alignItems: "center",
            padding: "10px 0",
            borderBottom: i < txns.length - 1 ? "1px solid rgba(255,255,255,0.05)" : "none",
          }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <span style={{ fontSize: "0.85rem", fontWeight: 500 }}>{t.merchant}</span>
              <span style={{ fontSize: "0.7rem", color: "var(--muted)", fontFamily: "var(--font-mono)" }}>{t.meta}</span>
            </div>
            <span style={{ fontFamily: "var(--font-mono)", fontWeight: 500, fontSize: "0.88rem", color: t.type === "debit" ? "#ef4444" : "var(--teal)" }}>
              {t.amount}
            </span>
          </div>
        ))}

        {/* Risk score */}
        <div style={{
          marginTop: 20, padding: "14px 16px",
          background: "rgba(0,212,170,0.05)", border: "1px solid rgba(0,212,170,0.15)",
          borderRadius: 10,
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
            <span style={{ fontSize: "0.78rem", color: "var(--muted)" }}>Overall Risk Score</span>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "1.5rem", fontWeight: 800, color: "var(--amber)" }}>62.8</span>
          </div>
          <div style={{ height: 4, background: "rgba(255,255,255,0.1)", borderRadius: 2 }}>
            <div style={{ height: "100%", width: "62.8%", background: "linear-gradient(to right, var(--teal), var(--amber))", borderRadius: 2 }} />
          </div>
        </div>
      </div>
    </section>
  );
}
