import { useEffect, useRef, useState } from "react";

const features = [
  { icon: "🧠", title: "SHAP Explanations", desc: "Every flagged transaction shows exactly which factors — amount, time, merchant, frequency — drove the risk score.", tag: "Explainable AI" },
  { icon: "📉", title: "Confidence Corridors", desc: "Risk scores arrive with uncertainty bands so analysts know precisely when to trust the model and when to step in.", tag: "Uncertainty Quantification" },
  { icon: "🧬", title: "Spending DNA Fingerprint", desc: "Builds a personalized behavioral baseline per user. Any deviation from their pattern instantly triggers a targeted alert.", tag: "Anomaly Detection" },
  { icon: "🕐", title: "Circadian Rhythm Detection", desc: "Learns the hours a user never transacts and automatically flags any activity outside their personal time window.", tag: "Behavioral AI" },
  { icon: "📡", title: "Financial Stress Index", desc: "Detects early distress signals — micro-withdrawals, cash surges, payday loan activity — before they escalate into crises.", tag: "Predictive" },
  { icon: "📝", title: "Forensic Report Generator", desc: "LLM narrates all flagged transactions into a single coherent story with a timeline, risk verdict, and action steps.", tag: "Court-Ready PDF" },
  { icon: "🔮", title: "Cash Flow Predictor", desc: "Forecasts daily balances up to 30 days ahead and warns of overdraft risk before it materializes.", tag: "Forecasting" },
  { icon: "🔎", title: "Smurfing Detector", desc: "Identifies structuring patterns where large amounts are split into smaller transactions to evade reporting thresholds.", tag: "AML Compliance" },
  { icon: "🌐", title: "OCR Multi-Format Support", desc: "Accepts CSV, PDF, and scanned images. Auto field extraction handles any bank's export format without configuration.", tag: "Data Ingestion" },
];

const metrics = [
  { name: "Anomaly Detection Recall", val: "94.2%", w: 94 },
  { name: "Smurfing Pattern Accuracy", val: "91.7%", w: 91 },
  { name: "False Positive Rate", val: "4.1%", w: 4 },
  { name: "OCR Field Extraction Accuracy", val: "98.3%", w: 98 },
  { name: "Report Generation Speed", val: "< 45s", w: 88 },
];

function SectionLabel({ children, style }) {
  return (
    <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.72rem", color: "var(--teal)", textTransform: "uppercase", letterSpacing: "0.12em", marginBottom: 16, display: "flex", alignItems: "center", gap: 10, ...style }}>
      <span style={{ display: "block", width: 28, height: 1, background: "var(--teal)" }} />
      {children}
    </div>
  );
}

function FeatureCell({ icon, title, desc, tag }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ background: hovered ? "var(--surface)" : "var(--bg)", padding: "34px 30px", transition: "background 0.3s", cursor: "default" }}
    >
      <div style={{ width: 48, height: 48, background: hovered ? "rgba(0,212,170,0.1)" : "var(--surface2)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: "1.2rem", marginBottom: 20, transition: "all 0.3s" }}>
        {icon}
      </div>
      <div style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "0.98rem", marginBottom: 10 }}>{title}</div>
      <p style={{ fontSize: "0.82rem", color: "var(--muted)", lineHeight: 1.6, fontWeight: 300 }}>{desc}</p>
      <span style={{
        display: "inline-block", marginTop: 14,
        fontFamily: "var(--font-mono)", fontSize: "0.64rem",
        padding: "3px 10px", borderRadius: 100,
        background: "rgba(0,212,170,0.1)", color: "var(--teal)",
        border: "1px solid rgba(0,212,170,0.2)",
      }}>{tag}</span>
    </div>
  );
}

function MetricBar({ name, val, w, animate }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span style={{ fontSize: "0.82rem", color: "var(--muted)" }}>{name}</span>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.82rem", color: "var(--teal)", fontWeight: 500 }}>{val}</span>
      </div>
      <div style={{ height: 3, background: "rgba(255,255,255,0.08)", borderRadius: 2 }}>
        <div style={{
          height: "100%", borderRadius: 2,
          background: w <= 5 ? "var(--teal)" : "linear-gradient(to right, var(--teal), var(--blue))",
          width: animate ? `${w}%` : "0%",
          transition: "width 1s ease",
        }} />
      </div>
    </div>
  );
}

export default function FeaturesPage() {
  const [metricsVisible, setMetricsVisible] = useState(false);
  const metricsRef = useRef(null);

  useEffect(() => { window.scrollTo(0, 0); }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(
      entries => { if (entries[0].isIntersecting) { setMetricsVisible(true); obs.disconnect(); } },
      { threshold: 0.3 }
    );
    if (metricsRef.current) obs.observe(metricsRef.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section style={{ minHeight: "100vh", padding: "120px 48px 80px", background: "var(--bg)" }}>
      <SectionLabel>Capabilities</SectionLabel>
      <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "clamp(2rem, 4vw, 3.2rem)", letterSpacing: "-0.03em", marginBottom: 16, lineHeight: 1.1 }}>
        Intelligence Built In
      </h2>
      <p style={{ color: "var(--muted)", maxWidth: 520, lineHeight: 1.7, marginBottom: 64, fontWeight: 300 }}>
        Eight advanced AI models power every analysis — from explainable risk scoring to smurfing detection.
      </p>

      {/* 3-col feature grid */}
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(3, 1fr)",
        gap: 1, background: "var(--border)",
        border: "1px solid var(--border)", borderRadius: 20, overflow: "hidden",
      }}>
        {features.map(f => <FeatureCell key={f.title} {...f} />)}
      </div>

      {/* AI Metrics strip */}
      <div style={{ marginTop: 80, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48, alignItems: "center" }}>
        <div>
          <SectionLabel>Model Performance</SectionLabel>
          <h2 style={{ fontFamily: "var(--font-display)", fontWeight: 800, fontSize: "clamp(1.8rem, 3vw, 2.6rem)", letterSpacing: "-0.03em", marginBottom: 16, lineHeight: 1.1 }}>
            Smarter Risk<br />Detection
          </h2>
          <p style={{ color: "var(--muted)", lineHeight: 1.7, fontWeight: 300, fontSize: "0.95rem" }}>
            Each AI component is independently validated on financial transaction datasets covering millions of records across diverse banking formats.
          </p>
        </div>

        <div ref={metricsRef} style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          {metrics.map(m => <MetricBar key={m.name} {...m} animate={metricsVisible} />)}
        </div>
      </div>
    </section>
  );
}
